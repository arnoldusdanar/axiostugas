import React, { useState } from 'react';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [welcomeMessage, setWelcomeMessage] = useState('');

  const handleLoginClick = () => {
    setIsLoggedIn(!isLoggedIn);
    setWelcomeMessage('Welcome Tono Sucipto');
  };

  const handleLogoutClick = () => {
    setIsLoggedIn(false);
    setWelcomeMessage('');
  };

  return (
    <div className="">
      <div className='flex justify-between items-center flex-col md:flex-row mb-4'>
        <img src="./logo-kodak.jpg" alt="" />
      {isLoggedIn && (
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={handleLogoutClick}
          >
            Logout
          </button>
        
      )}
      {!isLoggedIn && (
        <button
          className="mt-4 md:mt-0 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          onClick={handleLoginClick}
        >
          Login
        </button>
      )}
      </div>
      {welcomeMessage && (
            <h1 className="text-2xl p-2 bg-blue-300 rounded text-center font-bold h-screen ">{welcomeMessage}</h1>
          )}
    </div>
  );
}

export default App;
